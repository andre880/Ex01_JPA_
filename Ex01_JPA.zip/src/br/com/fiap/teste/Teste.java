package br.com.fiap.teste;

import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.com.fiap.entity.Autor;
import br.com.fiap.entity.Editora;
import br.com.fiap.entity.Livro;
import br.com.fiap.entity.Sexo;

public class Teste {

	public static void main(String[] args) {
		EntityManagerFactory factory = 
				Persistence.createEntityManagerFactory("CLIENTE_ORACLE");
		EntityManager em = factory.createEntityManager();
		
		Autor aut = new Autor(0, "George", Sexo.MASCULINO, "R R MARTIN", 
				new GregorianCalendar(1934, Calendar.JANUARY, 23));
		
		Editora edi = new Editora(0, "0191019293", "Penguin", "R. Camilo Carrera");
		
		Livro liv = new Livro(0, "A Song Of Ice And Fire", 200, new GregorianCalendar(1997, Calendar.JANUARY, 20), null);

		em.persist(aut);
		em.persist(edi);
		em.persist(liv);
		
		em.getTransaction().begin();
		em.getTransaction().commit();
		System.out.println("Cadastrado!");
		
		em.close();
		factory.close();

	}

}
