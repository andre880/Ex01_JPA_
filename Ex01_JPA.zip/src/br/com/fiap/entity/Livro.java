package br.com.fiap.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TB_Livro")
@SequenceGenerator(name = "seqLivro", sequenceName="SQ_LIVRO", allocationSize=1)
public class Livro {
	@Id
	private int isbn;
	@Column(name = "NM_TITULO", nullable=false, length=300)
	private String titulo;
	@Column(name = "VL_PRECO")
	private float preco;
	@Column(name="DT_LANCAMENTO")
	@Temporal(TemporalType.DATE)
	private Calendar dtLanca;
	@Lob
	private byte[] capa;
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public float getPreco() {
		return preco;
	}
	public void setPreco(float preco) {
		this.preco = preco;
	}
	public Calendar getDtLanca() {
		return dtLanca;
	}
	public void setDtLanca(Calendar dtLanca) {
		this.dtLanca = dtLanca;
	}
	public byte[] getCapa() {
		return capa;
	}
	public void setCapa(byte[] capa) {
		this.capa = capa;
	}
	public Livro(int isbn, String titulo, float preco, Calendar dtLanca, byte[] capa) {
		super();
		this.isbn = isbn;
		this.titulo = titulo;
		this.preco = preco;
		this.dtLanca = dtLanca;
		this.capa = capa;
	}
	public Livro() {
		super();
	}
	
	

}
