package br.com.fiap.entity;

public enum Sexo {

	FEMININO, MASCULINO, OUTROS;
	
}
